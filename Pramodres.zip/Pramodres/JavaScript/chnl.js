console.log('Hello');

document.getElementById('chmovies')
    .addEventListener('click', function() {
        location.href = 'chnlmovies.html'
    });
    
document.getElementById('selfgrowth')
    .addEventListener('click', function() {
        location.href = 'chnlselfgrowth.html'
    });
